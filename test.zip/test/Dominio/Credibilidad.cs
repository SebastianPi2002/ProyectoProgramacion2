﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dominio
{
    public enum Credibilidad
    {
        Bajo,
        Medio, 
        Alto
    }
}
